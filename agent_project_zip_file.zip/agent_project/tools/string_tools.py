import json
def string_question(input_string):
    """
    Reverse a given string.
    Input: A string to reverse.
    Output: The reversed string.
    """
    return input_string[::-1]
