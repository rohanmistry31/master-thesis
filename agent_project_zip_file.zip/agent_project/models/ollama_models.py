import requests
import json
import os
from utils.get_keys import load_config

# Load configuration

class OllamaModel:
    def __init__(self, model, system_prompt, temperature=0, stop=None):
        
        self.model_endpoint = "http://localhost:11434/api/generate"
        self.temperature = temperature
        self.model = model
        self.system_prompt = system_prompt
        self.headers = {"Content-Type": "application/json"}
        self.stop = stop

    def generate_text(self, prompt):
       
        payload = {
            "model": self.model,
            "format": "json",
            "prompt": prompt,
            "system": self.system_prompt,
            "stream": False,
            "temperature": self.temperature,
            "stop": self.stop
        }

        try:
            request_response = requests.post(
                self.model_endpoint, 
                headers=self.headers, 
                data=json.dumps(payload)
            )
            
            print("REQUEST RESPONSE", request_response)
            request_response.raise_for_status()  # Raise an error for bad responses

            request_response_json = request_response.json()
            # Ensure the response contains the expected fields
            if 'response' not in request_response_json:
                return {"error": "Response format is unexpected."}

            response = request_response_json['response']
            
            # Attempt to decode the response if it's a JSON string
            try:
                response_dict = json.loads(response)
            except json.JSONDecodeError:
                return {"error": "Failed to decode response JSON."}

            print(f"\n\nResponse from Ollama model: {response_dict}")

            return response_dict
        except requests.RequestException as e:
            return {"error": f"Error in invoking model! {str(e)}"}