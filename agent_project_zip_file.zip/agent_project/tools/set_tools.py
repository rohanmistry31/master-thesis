import json

def set_question(input_set):
    """
    Generate a question related to set operations.
    """
    union_set = input_set.union({7, 8})
    return {
        "question": f"If you perform a union operation on {input_set} with {{7, 8}}, what will be the result?",
        "answer": union_set
    }