import random

def generate_question():
    """
    Generate a Python question based on data structure operations.
    """
    questions = [
        {"type": "list", "question": "What is [1, 2, 3] + [4, 5]?", "answer": [1, 2, 3, 4, 5]},
        {"type": "dictionary", "question": "What is the value of 'key1' in {'key1': 10, 'key2': 20}?", "answer": 10},
    ]
    return random.choice(questions)
