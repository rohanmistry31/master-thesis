def list_operations(input_list, operation, value=None):
    """
    Perform operations on a list: append, remove, or extend.
    
    Parameters:
    input_list (list): The list to modify.
    operation (str): The operation to perform ('append', 'remove', 'extend').
    value (optional): The value to append or remove, or the list to extend with.
    
    Returns:
    list or str: Updated list or an explanation message.
    """
    if operation == "append":
        if value is not None:
            input_list.append(value)
            return input_list
        else:
            return "Append operation requires a value."
    
    elif operation == "remove":
        if value in input_list:
            input_list.remove(value)
            return input_list
        else:
            return f"Value '{value}' not found in the list."
    
    elif operation == "extend":
        if isinstance(value, list):
            input_list.extend(value)
            return input_list
        else:
            return "Extend operation requires a list as value."
    
    else:
        return "Invalid operation. Supported operations: append, remove, extend."