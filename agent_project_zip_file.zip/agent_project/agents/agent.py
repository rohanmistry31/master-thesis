from termcolor import colored
from prompts.prompts import agent_system_prompt_template
from models.ollama_models import OllamaModel
from toolbox.toolbox import ToolBox
from tools.string_tools import string_question
from tools.list_tools import list_operations
from tools.tuple_tools import tuple_question
from tools.set_tools import set_question
from tools.dictionary_tools import dictionary_question
from tools.question_generator import generate_question



class Agent:
    def __init__(self, tools, model_service, model_name, stop=None):

        self.tools = tools
        self.model_service = model_service
        self.model_name = model_name
        self.stop = stop

    def prepare_tools(self):
      
        toolbox = ToolBox()
        toolbox.store(self.tools)
        tool_descriptions = toolbox.tools()
        return tool_descriptions

    def think(self, prompt):
   
        tool_descriptions = self.prepare_tools()
        agent_system_prompt = agent_system_prompt_template.format(tool_descriptions=tool_descriptions)

        # Create an instance of the model service with the system prompt

        if self.model_service == OllamaModel:
            model_instance = self.model_service(
                model=self.model_name,
                system_prompt=agent_system_prompt,
                temperature=0,
                stop=self.stop
            )
        else:
            model_instance = self.model_service(
                model=self.model_name,
                system_prompt=agent_system_prompt,
                temperature=0
            )

        # Generate and return the response dictionary
        agent_response_dict = model_instance.generate_text(prompt)
        return agent_response_dict

    def work(self, prompt):

        agent_response_dict = self.think(prompt)
        tool_choice = agent_response_dict.get("tool_choice")
        tool_input = agent_response_dict.get("tool_input")

        for tool in self.tools:
            if tool.__name__ == tool_choice:
                response = tool(tool_input)

                print(colored(response, 'cyan'))
                return
                # return tool(tool_input)

        print(colored(tool_input, 'cyan'))
        
        return


if __name__ == "__main__":
    tools = [
    string_question,
    list_operations,
    tuple_question,
    set_question,
    dictionary_question,
    generate_question
    ]

    model_service = OllamaModel
    model_name = 'llama3:8b'
    stop = "<|eot_id|>"

    agent = Agent(tools=tools, model_service=model_service, model_name=model_name, stop=stop)

    while True:
        prompt = input("Ask me about Python concepts or request a question for practice: ")
        if prompt.lower() == "exit":
            break

        # Test with a simple, direct question
        if not prompt.strip():
            print("Please enter a valid question.")
            continue

        agent.work(prompt)
